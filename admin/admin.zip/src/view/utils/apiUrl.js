const apiUrl =
  process.env.NODE_ENV === "production"
    ? "http://111.4.119.69:40605"
    : "http://111.4.119.69:40605";
export default apiUrl;
