
export function dataX1(){
    let arr1=["0:00", "2:00", "4:00", "6:00", "8:00", "10:00", "12:00", "14:00", "16:00", "18:00", "20:00", "22:00"]  
        return arr1;
 }
 export function dataY1(){
    let arr2=["传感器A","传感器B","传感器C"]
     return arr2;
 }
 
 export function dataZ1(){
     let arr3=[];
    for(let i=0;i<12;i++){
     arr3.push(Math.random()*30)
    }
 
     return arr3;
 }
 export function dataZ2(){
     let arr4=[];
     for(let i=0;i<12;i++){
         arr4.push(Math.random()*30)
        }
        return arr4;
 }
 export function dataZ3(){
     let arr5=[];
     for(let i=0;i<12;i++){
         arr5.push(Math.random()*30)
        }
        return arr5;
 }

 export function dataZ4(){
    let arr6=[];
    for(let i=0;i<12;i++){
        arr6.push(Math.random()*30)
       }
       return arr6;
}
export function dataZ5(){
    let arr7=[];
    for(let i=0;i<12;i++){
        arr7.push(Math.random()*30)
       }
       return arr7;
}