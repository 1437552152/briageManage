define(["exports","./when-7ef6387a"],(function(t,n){"use strict";t.GeometryAttributes=function(t){t=n.defaultValue(t,n.defaultValue.EMPTY_OBJECT),this.position=t.position,this.normal=t.normal,this.st=t.st,this.bitangent=t.bitangent,this.tangent=t.tangent,this.color=t.color}}));
//# sourceMappingURL=GeometryAttributes-cb18da36.js.map
